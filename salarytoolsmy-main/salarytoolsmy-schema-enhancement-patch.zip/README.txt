================================================================================
SalaryToolsMY.com — Schema Enhancement Patch
================================================================================

PURPOSE
-------
Add valid JSON-LD structured data (schema.org) to SalaryToolsMY.com pages
without changing any visible design, layout, header, footer, calculator logic,
mobile navigation, or article content.

WHAT CHANGED
------------
For each file listed below, ONLY the following was added:
  - <script type="application/ld+json"> blocks inserted immediately BEFORE </head>
No other HTML, CSS, JavaScript, or content was modified.

FILES IN THIS PATCH
-------------------
1. index.html
   Added schemas:
   - Organization + WebSite (site-level, with @id cross-references)
   - BreadcrumbList (Home)
   - FAQPage (3 FAQs matching the visible FAQ section)
   - WebApplication (Quick Salary Estimate tool on homepage)

2. salary-calculator-malaysia.html
   NOTE: The URL /salary-calculator.html returns 404.
         The correct page is /salary-calculator-malaysia.html.
   Added schemas:
   - BreadcrumbList (Home > Salary Calculator Malaysia)
   - WebApplication (Salary Calculator)
   - FAQPage (6 FAQs matching visible FAQ section)

3. epf-deduction-from-salary-malaysia.html
   Added schemas:
   - BreadcrumbList (Home > EPF Deduction from Salary Malaysia)
   - Article (guide/informational page)
   - FAQPage (10 FAQs matching visible FAQ section)

4. socso-calculator-malaysia.html
   NOTE: The URL /socso-contribution-malaysia.html returns 404.
         The correct page is /socso-calculator-malaysia.html.
   Added schemas:
   - BreadcrumbList (Home > SOCSO Calculator Malaysia)
   - WebApplication (SOCSO Calculator)
   - FAQPage (8 FAQs matching visible FAQ section)

5. pcb-calculator-malaysia.html
   Added schemas:
   - BreadcrumbList (Home > PCB Calculator Malaysia)
   - WebApplication (PCB Calculator)
   - FAQPage (9 FAQs matching visible FAQ section)

6. minimum-salary-malaysia-2026.html
   Added schemas:
   - BreadcrumbList (Home > Minimum Salary Malaysia 2026)
   - Article (guide/informational page)
   - FAQPage (9 FAQs matching visible FAQ section — rendered as h3/p pairs)

7. about.html
   Added schemas:
   - BreadcrumbList (Home > About)

8. contact.html
   Added schemas:
   - BreadcrumbList (Home > Contact)

SCHEMA SUMMARY
--------------
Schema Type          | Pages Using It
---------------------+------------------------------------------
Organization/WebSite | index.html (homepage only, with @id refs)
BreadcrumbList       | All 8 pages
FAQPage              | index.html, salary-calculator, epf-deduction,
                     | socso-calculator, pcb-calculator,
                     | minimum-salary-2026
Article              | epf-deduction, minimum-salary-2026
WebApplication       | index.html, salary-calculator, socso-calculator,
                     | pcb-calculator

HOW TO APPLY
------------
For each file in this patch:

1. Open the corresponding live HTML file on your server.
2. Locate the closing </head> tag.
3. Copy ALL <script type="application/ld+json"> blocks from the
   corresponding patch file.
4. Paste them immediately BEFORE the </head> tag.
5. Save and deploy.

Each patch file contains clear HTML comments indicating where to insert.

WHAT WAS NOT CHANGED
--------------------
- Page design / layout / CSS — untouched
- Header — untouched
- Footer — untouched
- Calculator JavaScript logic — untouched
- Mobile navigation — untouched
- Article body content — untouched
- No noindex tags added
- No fake reviews added
- No AggregateRating added
- FAQ schema ONLY matches visible FAQ content already on the page

IMPORTANT NOTES
---------------
- Organization schema uses @id cross-references so WebApplication and
  Article schemas can reference the same Organization entity consistently.
- The logo URL points to /assets/logo.png. If your logo uses a different
  path, update the "url" field in the Organization schema on index.html.
- Article datePublished is set based on sitemap lastmod dates.
- No robots.txt or meta robots changes are included.
- /sitemap.xml does not require changes for this patch.

VALIDATION
----------
After applying, validate each page using:
- Google Rich Results Test: https://search.google.com/test/rich-results
- Schema Markup Validator: https://validator.schema.org

================================================================================
